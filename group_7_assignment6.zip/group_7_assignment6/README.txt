Press the "play" button to display the animation. 

Click anywhere on the screen to dirturb the nearby snowflakes.