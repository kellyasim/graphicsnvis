Press the "play" button to start the game. 

Use: 
'w' to move up
'a' to move left
's' to move down
'd' to move right

'j' to attack
'p' for tutorial/move keys and to pause/unpause the game
'r' to restart the game