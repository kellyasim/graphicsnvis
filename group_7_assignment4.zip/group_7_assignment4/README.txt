This program requires the Sound library to be installed.

Once it has been installed, clicking play will display the animation.