Press the "play" button to start each visualization. 

Further Instructions:

PART I- 
pressing 0 will display actual weight minus reported weight for both genders
pressing 1 will display actual height minus reported height for both genders
pressing 2 will display actual weight minus reported weight for men
pressing 3 will display actual height minus reported height for men
pressing 4 will display actual weight minus reported weight for women
pressing 5 will display actual height minus reported height for women
pressing 9 will toggle the display for the outliers


PART II-
Once it loads, click on the mouse once to reset the camera view. After the reset, the user can toggle between the two views (3/4th view and bird's eye view). In the 3/4th view the focus of the camera is based on mouseX and mouseY values. In the bird's eye view is looking down on the graph from above showing a 3D mimic of a 2D graph with the z axis imitating the y axis for this view.


PART III- 
Let programing load (1-2min). Even if the page is displaying images thumbnails allow for 10-20sec for it ot fetch all thumbnails. It may take several clicks if not entirely loaded to go through feed.  Once loaded the user can scroll through the mail BBC World News feed or select the 5 other feeds. The colors in the BBC World News feed are coded to their respective feed (i.e. if news is from african feed it will). Hovering over the title will produce the description in the bottom left corner. double click the title will lauch the link in the user's default browser.
