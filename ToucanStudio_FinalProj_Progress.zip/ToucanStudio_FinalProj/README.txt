Press "play" to begin game. Please be patient as assets may take a while to load.


Use: 
'w' or "up arrow" to move up
'a' or "left arrow" to move left
's' or "down arrow" to move down
'd' or "right arrow" to move right

'j' or "space bar" to attack
'p' for tutorial/move keys and to pause/unpause the game
'r' to restart the game


